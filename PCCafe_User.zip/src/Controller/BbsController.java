package Controller;

import Serviece.BbsServiece;


public class BbsController {
	BbsServiece BbsServiece = new BbsServiece();
}