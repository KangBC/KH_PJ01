package Serviece;

import java.util.List;

import Dao.BbsDao;
import Dto.BbsDto;


public class BbsServiece {

	BbsDao dao = new BbsDao();

}
