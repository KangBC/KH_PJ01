package Serviece;

public class BbsServiece {

}
