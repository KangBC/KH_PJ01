package Controller;

public class BbsController {

}
