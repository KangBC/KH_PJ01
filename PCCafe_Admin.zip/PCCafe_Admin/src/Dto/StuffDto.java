package Dto;

public class StuffDto {

}
