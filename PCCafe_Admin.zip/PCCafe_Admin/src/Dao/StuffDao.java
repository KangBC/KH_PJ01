package Dao;

public class StuffDao {

}
